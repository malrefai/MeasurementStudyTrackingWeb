CREATE TABLE pages(
	id INTEGER PRIMARY KEY ASC,
	location TEXT,
	parent_id INTEGER
);