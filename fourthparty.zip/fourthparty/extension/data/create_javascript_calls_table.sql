CREATE TABLE javascript_calls(
	id INTEGER PRIMARY KEY ASC,
	javascript_id INTEGER,
	parameter_index INTEGER,
	value TEXT
);