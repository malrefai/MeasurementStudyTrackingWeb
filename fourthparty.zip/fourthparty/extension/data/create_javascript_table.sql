CREATE TABLE javascript(
	id INTEGER PRIMARY KEY ASC,
	page_id INTEGER,
	symbol TEXT,
	operation TEXT,
	value TEXT
);