CREATE TABLE http_requests(
	id INTEGER PRIMARY KEY ASC,
	url TEXT,
	method TEXT,
	referrer TEXT,
	page_id INTEGER
);